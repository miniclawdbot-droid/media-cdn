# How Sub-Agents Work in OpenClaw

*The concepts behind the templates — and how to use them effectively.*

---

## Orchestrator vs Sub-Agent

Every OpenClaw setup has one orchestrator: the main agent that reads your context files and responds to your messages. The orchestrator is the decision-maker. It figures out what needs to happen and routes work to the right place.

Sub-agents are workers. Each one has a specific job: research, write, review, publish. They receive a task from the orchestrator, do that task, and report back. They don't make strategic decisions. They execute.

The reason to separate them is focus. A research agent that's also trying to write content will do both worse than two separate agents each doing one thing. Clear roles, clear outputs, cleaner results.

---

## When to Spawn vs Handle Directly

Not every task needs a sub-agent. Spawning one has overhead: the context is set up, the task is passed, the output comes back. For simple tasks, that overhead isn't worth it.

**Handle directly (orchestrator does it):**
- Quick lookups and web searches
- Simple file reads or updates
- Answering a question where you already have the context
- Tasks that don't fit a clean sub-agent role

**Spawn a sub-agent:**
- Multi-step tasks with a clear workflow (research → write → review)
- Tasks that need a specific persona or voice the orchestrator doesn't carry
- Parallel work (researching two topics simultaneously)
- Tasks where you want strict separation of concerns (publisher should only publish — never edit)

The test: if the task has a clear input and a clear output and benefits from specialization, spawn a sub-agent. If it's a quick action, just do it.

---

## How to Write a Good Sub-Agent Task

The quality of the sub-agent's output depends almost entirely on the quality of the task you give it. Garbage in, garbage out.

A good task has:

**1. A clear role statement.** The agent reads this and knows who it is for this task.
> "You are the Research Agent for GrowthLab."

**2. A specific, scoped goal.** Not "research AI news" — "find the top 3 AI tool releases in the last 7 days, with source URLs."

**3. The inputs it needs.** Any context, constraints, source material, or reference files.

**4. A defined output format.** What do you want back? A list? A formatted draft? A structured report? Tell it.

**5. What to do if stuck.** "If you can't find a primary source, flag it as unverified and move on."

A bad task is vague about any of these. The agent will fill in the gaps with assumptions, and the assumptions will be wrong half the time.

---

## Passing Context Between Agents

Sub-agents don't share memory. When the research agent finishes, the writer doesn't automatically know what it found. The orchestrator is responsible for passing context forward.

The pattern that works:
1. Research agent returns findings in a structured format (see researcher.md template)
2. Orchestrator receives the output
3. Orchestrator spawns writer with the research output pasted directly into the task

Don't summarize the research before passing it. Pass the actual output. Summarizing loses detail that the next agent might need.

If a chain has more than three steps, consider saving intermediate outputs to a file and passing the file path. This keeps the task prompt manageable and creates an audit trail.

---

## Sequential vs Parallel

Most workflows are sequential: research finishes, then writing starts, then review happens. Each step depends on the previous one. This is the default pattern.

Parallel spawning is for independent tasks. If you need to research two separate topics at the same time, spawn two research agents simultaneously. They run in parallel, both report back, and you combine the results.

Use parallel when:
- Tasks are genuinely independent (researching Topic A doesn't affect Topic B)
- Speed matters more than simplicity
- You can clearly separate the outputs afterward

Don't use parallel for tasks that depend on each other. Trying to write before research finishes, or review before writing is done, creates race conditions that are annoying to debug.

---

## Common Failure Modes and Fixes

**Sub-agent ignores the task and does something related but different.**
Fix: The task was too vague. Add specificity. Name the exact output you want. "Return a list of 3-5 items in this format: [format]."

**Sub-agent output is too long and unstructured.**
Fix: Specify output format explicitly in the task. "Return findings in this exact format: [template]." Without this, agents default to natural language explanations.

**Research agent returns unverified claims as fact.**
Fix: Add "Flag anything you cannot trace to a primary source with ⚠️ Unverified" to the task. Better: build this into the researcher.md template so it's always the default.

**Writer doesn't match brand voice.**
Fix: Paste the voice guidelines from SOUL.md directly into the writer task, not just "use brand voice." The agent needs to see the actual guidelines, not a reference to a file it can't read.

**Publisher posts to the wrong platform or connection ID.**
Fix: Always include the specific connection ID in the publishing task. Never reference "the LinkedIn account" — reference the connection ID from your publisher config. Ambiguity causes wrong-platform posts.

**Chain breaks mid-way and you don't know where.**
Fix: Log outputs at each step. Each agent reports its status before the orchestrator moves to the next one. "Research complete: 4 stories found, 2 verified, 2 flagged." That log tells you exactly where things worked and where they didn't.

---

## The Bigger Picture

Sub-agents aren't magic. They're a way to organize complexity and apply focus. The templates in this kit give you a working starting point for four of the most common agent roles: research, write, review, publish.

Customize them for your workflow. Add agents for tasks you do repeatedly. Remove ones you don't need. The structure matters more than following any specific template exactly.

The agents that work best over time are the ones with the clearest job descriptions, the most specific output formats, and an orchestrator that knows when to spawn them and when to just do the task directly.

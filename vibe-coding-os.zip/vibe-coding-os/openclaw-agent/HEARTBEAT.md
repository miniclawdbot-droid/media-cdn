# HEARTBEAT.md — Scheduled Tasks

> The agent reads this file when it receives a heartbeat poll. It follows the instructions here and reports back.
> This file controls your agent's proactive behavior: what it checks, when, and what to do with findings.

---

## API Configuration

> Fill in the APIs and services your agent needs for scheduled tasks. Keep actual keys in `.env` or your system keychain — not here.

| Service | Purpose | Key/Token Variable | Notes |
|---------|---------|-------------------|-------|
| [Service name] | [What it's used for] | `[ENV_VAR_NAME]` | [Any notes] |
| [Service name] | [What it's used for] | `[ENV_VAR_NAME]` | [Any notes] |

> Example:
> | Late API | Social media publishing | `LATE_API_KEY` | Use v1 endpoints only |
> | Resend | Email notifications | `RESEND_API_KEY` | Transactional only |
> | Airtable | Content tracking | `AIRTABLE_API_KEY` | Base ID: appXXXXX |

---

## Task Schedule

> Define what runs on each heartbeat. Heartbeats can be configured for any cadence — every 30 minutes, hourly, daily, etc.
> The "State Field" column is what to check in `heartbeat-state.json` to know if this task is due.

| Task | Cadence | Agent Chain | State Field | Priority |
|------|---------|-------------|-------------|----------|
| [Task name] | [e.g., "2x daily"] | [agent → agent] | `last[TaskName]` | [High/Med/Low] |
| [Task name] | [e.g., "Daily, 9am"] | [agent] | `last[TaskName]` | [High/Med/Low] |
| [Task name] | [e.g., "Weekly"] | [agent → agent → agent] | `last[TaskName]` | [High/Med/Low] |

> Example schedule:
> | Check email | 3x daily | [check directly] | lastEmailCheck | High |
> | Draft daily content | Daily | researcher → writer → reviewer | lastContentDraft | High |
> | Scan competitors | Weekly | competitor → analyzer | lastCompetitorScan | Medium |
> | Analytics review | Weekly | analytics | lastAnalyticsReview | Medium |

---

## Task Details

> For each scheduled task, define exactly what to do. Be specific — the agent reads this literally.

### [Task Name 1]

**Cadence:** [When this runs]
**Goal:** [What you're trying to accomplish]
**Steps:**
1. [Step 1 — specific action]
2. [Step 2]
3. [Step 3 — what to do with the output]

**Output:** [Where results go — e.g., "Save to memory/YYYY-MM-DD.md", "Post to Discord", "Draft saved to drafts/"]
**Skip if:** [Condition where this can be skipped — e.g., "Already ran in the last 4 hours"]

> Worked example:
>
> ### Morning Content Check
> **Cadence:** Daily, first heartbeat after 8am
> **Goal:** Check for breaking news in [niche] and flag anything worth writing about
> **Steps:**
> 1. Search [keyword 1], [keyword 2], [keyword 3] — last 24 hours
> 2. Filter for: primary sources only, verifiable, relevant to audience
> 3. List top 3 stories with headline, URL, and one-sentence "why it matters"
> 4. Save list to memory/YYYY-MM-DD.md under "Content Opportunities"
> 5. If anything is urgent (major announcement, breaking change), notify [owner] via [channel]
> **Output:** memory/YYYY-MM-DD.md + optional notification
> **Skip if:** Already ran today

---

### [Task Name 2]

**Cadence:** [When this runs]
**Goal:** [What you're trying to accomplish]
**Steps:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Output:** [Where results go]
**Skip if:** [Skip condition]

---

## Feedback Integration

> How the agent incorporates feedback from the owner into future behavior.

When the owner gives feedback on output (tone, quality, format, timing), log it in `memory/feedback.json`:

```json
{
  "feedbackLog": [
    {
      "date": "YYYY-MM-DD",
      "task": "[task name]",
      "feedback": "[what owner said]",
      "adjustment": "[how agent should change behavior]"
    }
  ]
}
```

Review feedback.json during each relevant task. If the same feedback has been given twice, treat it as a permanent adjustment.

---

## Heartbeat State Format

> The agent reads and updates this file to track what's been done.

File path: `memory/heartbeat-state.json`

```json
{
  "lastChecks": {
    "email": null,
    "contentDraft": null,
    "competitorScan": null,
    "analyticsReview": null
  }
}
```

- Values are Unix timestamps (seconds since epoch) or null if never run.
- Update the relevant field after completing each task.
- Use this to determine if a task is due before running it.

---

## When to Reach Out vs Stay Quiet

**Notify the owner when:**
- Something urgent or time-sensitive is found
- A task fails and needs their attention
- Content is ready for review/approval
- Something important happened that they'd want to know

**Stay quiet (HEARTBEAT_OK) when:**
- Nothing is due and nothing is urgent
- It's late night (define your own quiet hours)
- You just reported something less than 30 minutes ago
- Everything is running normally

---

> Keep this file small. The longer it gets, the more token burn per heartbeat. One well-written task definition beats five vague bullet points.

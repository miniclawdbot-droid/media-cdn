# OpenClaw Agent — Quickstart

*Get a working agent in 30 minutes. This is a real walkthrough, not a feature list.*

---

## What You're Building

A personal AI agent that lives on your machine, reads your context files, connects to a channel (Discord or Telegram), and responds to your messages — with memory, scheduled tasks, and sub-agent support.

This guide gets you to a working first run. Customization comes after.

---

## Prerequisites

- Node.js 18+ installed
- A Discord server you control, or a Telegram bot token
- 30 minutes uninterrupted

---

## Step 1: Install OpenClaw

```bash
npm install -g openclaw
```

Verify it worked:

```bash
openclaw --version
```

If you see a version number, you're good. If you get "command not found," add npm global bin to your PATH:

```bash
export PATH="$PATH:$(npm config get prefix)/bin"
```

---

## Step 2: Create Your Workspace

Your workspace is a folder on your machine. This is where your agent's identity and memory live.

```bash
mkdir ~/my-agent
cd ~/my-agent
openclaw init
```

This creates the folder structure your agent expects. You'll fill in the files in the next step.

---

## Step 3: Drop In Your Core Files

Your agent reads a set of Markdown files at the start of every session. These files define who it is, what it knows, and how it behaves.

Copy the template files from this kit into your workspace:

```bash
cp /path/to/vibe-coding-os/openclaw-agent/SOUL.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/IDENTITY.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/AGENTS.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/MEMORY.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/MISSION.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/USER.md ~/my-agent/
cp /path/to/vibe-coding-os/openclaw-agent/TOOLS.md ~/my-agent/
```

Now open each file and fill in the placeholders. Start with `SOUL.md` and `IDENTITY.md` — these define the agent's personality and context. `USER.md` is the shortest; fill it in first to warm up.

Minimum to fill in before first run:
- `SOUL.md`: Who the agent is and what it does
- `IDENTITY.md`: Name, what projects it supports
- `USER.md`: Your name and timezone

Everything else can be filled in after you have a working agent.

---

## Step 4: Configure Your Channel

### Option A: Discord

1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Create a new application. Give it your agent's name.
3. Go to Bot, click "Add Bot."
4. Copy the bot token.
5. Under OAuth2, add the bot to your server with `bot` scope and `Send Messages`, `Read Message History`, `Add Reactions` permissions.
6. In your workspace, create `.openclaw/config.json`:

```json
{
  "channel": "discord",
  "discord": {
    "token": "YOUR_BOT_TOKEN_HERE",
    "guildId": "YOUR_SERVER_ID",
    "channelId": "YOUR_CHANNEL_ID"
  },
  "model": "claude-sonnet-4-5",
  "workspaceDir": "/Users/yourname/my-agent"
}
```

Get your server ID: right-click your server name in Discord, "Copy Server ID." (Enable Developer Mode in Settings > Advanced if you don't see this option.)

### Option B: Telegram

1. Message @BotFather on Telegram, run `/newbot`
2. Follow the prompts, copy your bot token
3. Create `.openclaw/config.json`:

```json
{
  "channel": "telegram",
  "telegram": {
    "token": "YOUR_BOT_TOKEN_HERE"
  },
  "model": "claude-sonnet-4-5",
  "workspaceDir": "/Users/yourname/my-agent"
}
```

---

## Step 5: First Run

```bash
openclaw start
```

You should see something like:

```
OpenClaw starting...
Workspace: /Users/yourname/my-agent
Channel: discord
Model: claude-sonnet-4-5
Agent online. Send a message to wake it up.
```

Go to your Discord channel (or Telegram chat) and send a message. Your agent will read its context files and respond.

**First message to send:** "Hello — who are you and what do you do?"

This forces the agent to introduce itself based on what you put in SOUL.md and IDENTITY.md. If the response matches what you set up, you're done with the basics.

---

## Step 6: Run as a Background Service (Optional)

To keep the agent running after you close the terminal:

```bash
openclaw gateway start
```

Check status:

```bash
openclaw gateway status
```

Stop it:

```bash
openclaw gateway stop
```

On Mac, this runs as a launchd service. On Linux, it runs as a systemd service. It auto-restarts if it crashes.

---

## Common Gotchas

**"Agent doesn't respond to messages"**
Check that the bot has permission to read messages in the channel. In Discord, the bot needs `View Channel` and `Read Message History` permissions, not just `Send Messages`.

**"Agent responds but doesn't know anything about me"**
It's reading the template files with unfilled placeholders. Open `SOUL.md` and `IDENTITY.md` and fill them in. Restart the agent.

**"context.json not found" error**
Run `openclaw init` in your workspace directory first. This creates the folder structure the agent expects.

**"Model not found" error**
Check your config.json model name. Use `claude-sonnet-4-5` or `claude-haiku-4-5` — exact names, case-sensitive.

**Agent keeps forgetting things between sessions**
That's by design. The files are its memory. Update `MEMORY.md` with things you want it to remember long-term. Update `memory/YYYY-MM-DD.md` with session notes.

---

## What's Next

Once the agent is running, the rest is customization:
- Set up `HEARTBEAT.md` for scheduled tasks
- Set up `MISSION.md` with goals and priorities
- Add sub-agents from the `subagents/` templates for specific tasks
- Add environment-specific notes to `TOOLS.md`

See the full template files in this kit for how to do each of these.

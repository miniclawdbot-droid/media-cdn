# TOOLS.md — Local Environment Notes

> Skills define HOW tools work. This file is for YOUR specifics — the stuff unique to your setup.
> The agent reads this to know the local environment: device names, SSH hosts, API quirks, voice preferences.
> Update it when your setup changes.

---

## What Goes Here

Anything that's specific to your machine or setup that the agent needs to operate effectively:

- Camera names and locations (for smart home or security setups)
- SSH hosts and aliases (for server management)
- Preferred TTS voices (for voice output)
- Speaker or room names (for smart speakers)
- Device nicknames (for home automation)
- Browser profiles and their purposes
- API endpoint notes (non-sensitive — put keys in .env)
- Tool quirks and workarounds specific to your setup

What does NOT go here:
- API keys or secrets (those go in .env or your keychain)
- Generic how-to instructions (those go in SKILL.md files)
- Content or drafts (those go in content-hub/)

---

## Worked Examples

Fill in the sections below that apply to your setup. Delete sections you don't use.

---

### Cameras

> List cameras if your agent monitors or references them.

| Name | Location | Notes |
|------|----------|-------|
| [camera-name] | [Where it is] | [e.g., "Motion triggered, wide angle"] |
| [camera-name] | [Where it is] | [e.g., "Front-facing, outdoor"] |

> Example:
> | living-room | Main area, facing TV | 180 degree wide angle |
> | front-door | Entrance, exterior | Motion triggered, night vision |

---

### SSH Hosts

> List servers or machines the agent might need to connect to.

| Alias | Address | User | Notes |
|-------|---------|------|-------|
| [alias] | [IP or hostname] | [username] | [e.g., "Home server, Ubuntu 22.04"] |
| [alias] | [IP or hostname] | [username] | [e.g., "VPS, runs the dashboard"] |

> Example:
> | home-server | 192.168.1.100 | admin | Ubuntu 22.04, runs dashboard on :3456 |
> | vps-prod | prod.example.com | deploy | Production server, handle with care |

---

### TTS (Text-to-Speech)

> If you use voice output, define preferences here.

- **Preferred voice:** [e.g., "Nova — warm, slightly British"]
- **Default speaker:** [e.g., "Kitchen HomePod" / "main-speaker"]
- **Use voice for:** [e.g., "Summaries, reminders, storytime content"]
- **Don't use voice for:** [e.g., "Long reports, code blocks"]

---

### Browser Notes

> Browser profiles, login state, or session notes the agent should know.

- **Default profile:** [e.g., "openclaw — isolated browser, not logged into personal accounts"]
- **Research profile:** [e.g., "chrome — logged into Google, YouTube, Twitter for authenticated views"]
- **Notes:** [e.g., "Always close tabs after sessions. Never leave more than one tab open."]

---

### Devices and Smart Home

> Smart speakers, lights, or other controllable devices.

| Device | Name | Notes |
|--------|------|-------|
| [Device type] | [Name] | [How to reference it] |

---

### Stock Media and Assets

> Subscriptions, asset locations, or search conventions for media.

- **[Service name]:** [e.g., "Subscription active until [date]. Use for [purpose]."]
- **Local assets:** [e.g., "Brand assets in ~/assets/[brand-name]/"]
- **Search terms that work:** [e.g., "For 'discipline' content: solo workout, early morning, empty gym"]

---

### Dashboard or Internal Tools

> Any local tools, servers, or dashboards the agent should know about.

| Tool | URL / Path | Notes |
|------|-----------|-------|
| [Tool name] | [URL or path] | [What it does] |

> Example:
> | Content Hub | http://192.168.1.100:3456/ | Local dashboard for content pipeline |
> | Analytics | ~/reports/ | Weekly analytics exports live here |

---

### API Endpoint Notes

> Not keys — just structural notes about APIs you use.

- **[API name]:** [e.g., "Use v2 endpoints only. v1 is deprecated but still live — avoid."]
- **[API name]:** [e.g., "Rate limit is 60 requests/minute. Space out bulk operations."]
- **[API name]:** [e.g., "Webhook base URL: https://[your-domain]/webhooks/"]

---

> Add whatever helps you do the job. This is your cheat sheet for the local environment.

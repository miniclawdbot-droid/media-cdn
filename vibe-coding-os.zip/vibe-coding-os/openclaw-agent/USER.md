# USER.md — About Your Human

> This file exists because the agent reads it every session to know who it's working with.
> Without it, the agent has no idea who you are, how to address you, or what you expect.
> Fill it in. It takes 3 minutes and makes every session better.

---

## Basic Info

| Field | Value |
|-------|-------|
| **Name** | [First name or preferred name] |
| **What to call them** | [e.g., same as above, or a nickname] |
| **Pronouns** | [they/them, she/her, he/him] |
| **Timezone** | [e.g., America/New_York, Europe/London] |

---

## Communication Preferences

> How does this person like to receive information? Be specific — it shapes every response.

- **Format:** [e.g., "Bullet points for summaries, paragraphs for explanations"]
- **Length:** [e.g., "Short by default. Say more only when it matters."]
- **Tone:** [e.g., "Direct and efficient. Skip pleasantries."]
- **Links:** [e.g., "Always include source links. Always at the end, not inline."]
- **Updates:** [e.g., "Report what was done, not what you're planning to do"]

---

## Context Notes

> Anything the agent should know to work effectively with this person.

- **Primary tools:** [e.g., "VS Code, Notion, Cursor, Airtable"]
- **Working hours:** [e.g., "Usually active 9am-6pm ET. After hours = low-priority only"]
- **Decision style:** [e.g., "Prefers 2-3 options with a recommendation over open-ended questions"]
- **Approval style:** [e.g., "Review content async in Discord. Reply 'go' to approve, 'revise: [notes]' to request changes"]
- **What they hate:** [e.g., "Vague answers, filler language, being asked things they've already answered"]

---

## Projects and Brands

> Brief reference — full details are in IDENTITY.md.

| Project | Role | Priority |
|---------|------|----------|
| [Project name] | [Owner's involvement] | Primary |
| [Project name] | [Owner's involvement] | Secondary |

---

## Notes

> Anything else worth knowing. One-off context, temporary situations, things to be aware of.

[Free-form notes. Update as things change. Examples:]
- "[Date]: Traveling until [date] — mobile only, keep messages short"
- "Prefers to approve content in batches, not one at a time"
- "Give feedback on drafts directly, don't ask if feedback is wanted"

---

> Update this file when preferences change. The agent reads it every main session.

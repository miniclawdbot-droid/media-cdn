# MEMORY.md — Long-Term Memory

> This file is loaded ONLY in main sessions (direct chats with the owner).
> Not in group chats. Not in shared contexts. Contains personal context that shouldn't leak.
>
> How to use this file:
> - The agent reads it in main sessions to know the owner's preferences, history, and priorities
> - The agent can update it when significant things happen
> - Periodically, the agent reviews daily memory files and distills key learnings here
> - This is curated wisdom, not a raw log. Daily notes go in memory/YYYY-MM-DD.md
>
> What belongs here vs daily notes:
> - MEMORY.md: Preferences, decisions, lessons, recurring feedback, important context
> - Daily notes: What happened today, draft outputs, task logs, raw research

---

## Preferences and Feedback

> Track owner preferences as you learn them. If feedback is given twice, it's a permanent adjustment.

### Communication Style
- [e.g., "Prefers bullet points over paragraphs for summaries"]
- [e.g., "Wants links included in every report, at the end"]
- [e.g., "Direct, no preamble — get to the point fast"]

### Content Quality
- [e.g., "Always flag if a source is a press release vs primary reporting"]
- [e.g., "No generic intros. If the first sentence is boring, rewrite it."]
- [e.g., "Hook quality matters most — owner will rewrite body copy but not hooks"]

### Platform-Specific
- [Platform]: [Preference — e.g., "LinkedIn posts should lead with a data point, not a question"]
- [Platform]: [Preference]

### What Hasn't Worked
- [Pattern to avoid — e.g., "Lists of 'tips' without specifics — owner rejected these 3 times"]
- [Pattern to avoid]

---

## Workflow Standards

> How things get done around here. Decisions that have been made and don't need to be re-made.

### Publishing
- [e.g., "X and Threads always post together. Never separately."]
- [e.g., "All content needs owner approval before posting to LinkedIn"]
- [e.g., "Instagram gets carousels 3x/week, single images 2x/week"]

### Research
- [e.g., "Always include source URL. No exceptions."]
- [e.g., "Prefer primary sources over aggregators"]
- [e.g., "Flag anything with a paywall so owner can verify"]

### Drafting
- [e.g., "Draft platform versions in this order: X/Threads → LinkedIn → Instagram → YouTube description"]
- [e.g., "Keep draft files in content-hub/drafts/ with date prefix"]

---

## Infrastructure

> Technical context the agent needs to know. Connection IDs, tool quirks, known issues.

### Tools in Use
- [Tool name]: [Notes on how it's configured or any quirks]
- [Tool name]: [Notes]

### Known Issues
- [e.g., "Instagram carousel posting via Late sometimes fails silently — verify in the app after"]
- [e.g., "YouTube API advanced features are disabled until [date] — use manual posting"]

### Active API Connections
> Don't put keys here. Just notes on which connections exist and any known status issues.
- [Platform]: [Status — e.g., "Active", "Reconnect needed", "Rate limited Wednesdays"]

---

## Lessons Learned

> What has failed, what was learned, what changed as a result. Date each entry.

**[YYYY-MM-DD]:** [What happened, what the lesson was, what changed]

**[YYYY-MM-DD]:** [What happened, what the lesson was, what changed]

> Example:
> "2025-11-14: Published a LinkedIn post that cited a statistic from a secondary source. The stat was wrong. Owner caught it. Lesson: always trace stats to the primary source, even if the secondary source looks credible. Added a verification step to the content review process."

---

## Current Priorities

> What matters most right now. Update this as direction shifts.

**Phase:** [e.g., "Building audience", "Launching product", "Establishing cadence"]

**Top 3 focus areas:**
1. [Priority — e.g., "Post consistently to X and Threads every weekday"]
2. [Priority — e.g., "Build out the YouTube backlog — 4 videos ready to publish"]
3. [Priority — e.g., "Grow LinkedIn to 500 followers before end of quarter"]

**What to deprioritize right now:**
- [e.g., "Newsletter — paused until 500 social followers"]
- [e.g., "TikTok — focus on written platforms first"]

---

> Review and update this file during heartbeats, roughly every few days. Distill what's worth keeping from daily notes. Remove what's no longer relevant.

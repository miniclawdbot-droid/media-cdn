# PRD — [Project Name]

> One page. Fill this out before you write a single line of code. If you can't complete it, you're not ready to build yet.

---

## Problem
*What's broken, missing, or painful right now?*

> Why it matters: If you can't describe the problem in 1-2 sentences, you don't understand it well enough to solve it. AI will fill in the gaps you leave — usually wrong.

**The problem:**


---

## User
*Who specifically is this for? One person, not a demographic.*

> Why it matters: "Everyone" is not a user. The more specific you are, the better decisions you'll make when the AI asks "should I add feature X?"

**The user:**


---

## Core Features (3 max)
*What does this thing actually do? The minimum to solve the problem.*

> Why it matters: AI will happily build you 10 features. You need 3 that work, not 10 that kind of work. Every feature you add doubles your surface area for bugs.

1.
2.
3.

---

## Out of Scope
*What are you explicitly NOT building in this version?*

> Why it matters: This is your defense against scope creep. When AI suggests something that sounds useful, check this list. If it's here, say no — for now.

-
-
-

---

## Success Metric
*How do you know this worked? One specific, measurable thing.*

> Why it matters: Without a definition of done, you'll keep tweaking forever. Pick one metric. When you hit it, you've shipped.

**Done when:**


---

## Stack
*What technologies are you using? Be specific.*

> Why it matters: AI will pick whatever stack it wants if you don't specify. That's how you end up with a Python backend when you only know JavaScript.

- **Frontend:**
- **Backend:**
- **Database:**
- **Auth:**
- **Hosting:**
- **Other:**

---

## Constraints
*Any hard limits? Budget, timeline, existing codebase, must use X?*

> Why it matters: AI doesn't know your constraints. It'll suggest $500/mo infrastructure for a side project if you don't tell it you want to stay free tier.

-
-

---

*Last updated: [date]*
*Status: [Draft / Active / Shipped]*

---

---

# Filled Example — Task Timer App

> This is what a completed PRD looks like. Use it as a reference when filling out yours above.

---

## Problem

Freelancers forget to start timers, then have to guess how long tasks took. Manual time tracking is friction. Automated tools are overkill for solo freelancers.

**The problem:** Solo freelancers lose 30-60 minutes of billable time per week because manual time tracking is too annoying to do consistently.

---

## User

Maya, 28, freelance designer. She does 4-6 client projects at a time, charges by the hour, and uses Notion to manage projects. She's tried Toggl and Harvest — both felt like too much overhead for solo work. She wants something that takes 10 seconds to start and doesn't require a monthly subscription.

---

## Core Features (3 max)

1. One-click timer start/stop with a project name — no forms, no categories
2. Daily summary showing time logged per project
3. Export to CSV for invoice month-end

---

## Out of Scope

- Team features (no sharing, no seats, no managers)
- Invoicing or payment processing
- Mobile app (web only for now)
- Integrations with any third-party tools (Notion, Slack, etc.)
- User accounts / authentication (local storage only for v1)

---

## Success Metric

Done when Maya can track time for a full work day without thinking about the tool — meaning zero support messages or complaints after 5 days of use by 3 beta testers.

---

## Stack

- **Frontend:** Vanilla JS + HTML/CSS (no framework — Maya's a designer, wants to understand the code)
- **Backend:** None for v1 — all local storage
- **Database:** localStorage in the browser
- **Auth:** None (single-user, local only)
- **Hosting:** Netlify free tier (static site)
- **Other:** N/A

---

## Constraints

- Zero ongoing cost (free hosting, no backend)
- Must work offline (no API calls)
- Build time: 1 weekend
- Maya must be able to understand the codebase in case she wants to customize it later

---

*Last updated: 2026-03-01*
*Status: Active*

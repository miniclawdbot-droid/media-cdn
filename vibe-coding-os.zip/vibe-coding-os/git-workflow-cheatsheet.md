# Git Workflow Cheat Sheet
## Treat Commits Like Save Points

Every AI coding session should start with a clean checkpoint and end with your work saved. This workflow takes 30 seconds and has saved countless hours.

---

## Before Every AI Session

```bash
# Check what state things are in
git status

# Save everything before AI touches it
git add -A
git commit -m "checkpoint: before AI session [date]"
```

If `git status` shows uncommitted changes from last time, commit those first. Never start an AI session on a dirty repo.

---

## Before Every Major Change

```bash
# Before: refactors, new features, deleting anything, changing config
git add -A
git commit -m "checkpoint: before [what's about to change]"
```

Examples:
- `checkpoint: before refactoring auth flow`
- `checkpoint: before adding payment integration`
- `checkpoint: before AI rewrites the API layer`

Be specific. Future you will thank you.

---

## After a Working Session

```bash
# Save what you built
git add -A
git commit -m "feat: [what you built]"

# Push to remote so it's backed up
git push
```

---

## When AI Breaks Something — Rollback Commands

**Option 1: Undo the last commit, keep the files (softest)**
```bash
# Removes the last commit but leaves files untouched — you can edit and recommit
git reset HEAD~1
```

**Option 2: Undo last commit AND discard file changes (clean slate)**
```bash
# WARNING: This permanently discards any uncommitted changes in those files
git reset --hard HEAD~1
```

**Option 3: Discard ALL uncommitted changes right now**
```bash
# Reverts every modified file to the last committed state
git checkout -- .

# Or with modern git:
git restore .
```

**Option 4: Go back to a specific checkpoint by hash**
```bash
# Step 1: Find the commit you want
git log --oneline

# You'll see something like:
# abc1234 checkpoint: before AI session 2026-03-01
# def5678 feat: added login form
# ghi9012 checkpoint: before refactoring auth flow

# Step 2: Reset to that commit (this rewrites history — use with care)
git reset --hard abc1234

# Safer alternative: create a new branch from that point instead
git checkout -b recovery abc1234
```

**Option 5: Stash changes temporarily (not a commit, just a shelf)**
```bash
# Save current work without committing — useful mid-session
git stash

# Come back to it later
git stash pop

# See what's stashed
git stash list

# Drop a stash you don't want
git stash drop
```

---

## The "AI Wandered Too Far" Recovery Pattern

You gave AI a small task. It went on a 45-minute journey and now nothing works. Here's what to do:

```bash
# 1. Check what it actually changed
git diff

# 2. If you have a clean checkpoint from before the session:
git reset --hard [checkpoint-hash]

# 3. If you don't have a checkpoint (learn from this):
#    Undo one commit at a time until things work again
git reset --hard HEAD~1
# Test. Still broken?
git reset --hard HEAD~2
# Test. Until you find working state.
```

---

## Quick Reference

| Situation | Command |
|-----------|---------|
| Save current state | `git add -A && git commit -m "message"` |
| See what changed | `git status` |
| See all changes in detail | `git diff` |
| See commit history | `git log --oneline` |
| Undo last commit, keep files | `git reset HEAD~1` |
| Undo last commit, discard files | `git reset --hard HEAD~1` |
| Discard all uncommitted changes | `git checkout -- .` |
| Go back to specific commit | `git reset --hard [hash]` |
| Stash changes temporarily | `git stash` |
| Restore stashed changes | `git stash pop` |
| Push to remote | `git push` |
| Create recovery branch from old commit | `git checkout -b recovery [hash]` |

---

## The Rule

**One rule:** commit before AI does anything significant.

A 30-second commit has saved 3-hour debugging sessions more times than you want to know. Do it every time, even when you're sure it'll be fine. Especially when you're sure it'll be fine.

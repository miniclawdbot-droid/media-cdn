# Debugging With AI — When Your Project Breaks

*The three types of AI breaks, how to diagnose them, and how to recover.*

---

## The Uncomfortable Truth

When your AI-assisted project breaks, there's a natural instinct to ask the AI to fix what it broke. Sometimes that works. More often, you give it more rope and it uses it to create a second problem next to the first one.

Good AI debugging is methodical. You diagnose before you fix. You narrow the scope before you act. You roll back to known-good state when you're stuck, not after you've spiraled for an hour.

Here's the framework.

---

## The 3 Types of AI Breaks

### Type 1: Hallucinated Code

**What it looks like:** Code that references functions, packages, or APIs that don't exist. Often plausible-looking — correct syntax, wrong substance.

**Signs:** Import errors for packages you don't have. Function calls that throw "undefined is not a function." API methods that return nothing because they don't exist in the version you're using.

**Common triggers:** Asking AI to use a specific library it has limited training data on. Asking about cutting-edge APIs. Mixing up similar library APIs (React Query vs SWR, for example).

**Example:** AI writes `db.users.findAll({ where: conditions })` using Sequelize syntax, but you're using Prisma. It looks right. It fails immediately.

---

### Type 2: Context Drift

**What it looks like:** AI starts making changes that don't match your project's style, structure, or existing conventions. Usually happens in longer sessions or after many back-and-forth messages.

**Signs:** New files appear in unexpected locations. Variable naming patterns suddenly change. AI starts importing packages you already have under a different name. A function gets rewritten when you asked for one small change.

**Common triggers:** Long sessions without resetting context. Not having CLAUDE.md or .cursorrules in place. Pasting large blocks of code that crowd out earlier context.

**Example:** In message 3, you established that all API calls live in `/src/api/`. By message 20, AI is creating new API functions inline in components. It forgot.

---

### Type 3: Scope Creep

**What it looks like:** The code compiles, but it does more (or different) things than you asked for. AI solved a bigger problem than you gave it.

**Signs:** New UI elements you didn't ask for. Refactored code in files you didn't mention. Extra error handling, logging, or abstraction layers that weren't requested. A simple function that now has five parameters.

**Common triggers:** Vague prompts ("improve the auth system"). Not using the One-File Rule. Not reviewing diffs before accepting.

**Example:** You asked AI to add a loading spinner to the login form. It added the spinner, refactored the form validation, extracted two helper components, and installed a new animation library.

---

## Diagnosis Workflow

Before touching anything, diagnose the type of break. This determines the recovery path.

**Step 1: Does it fail to compile or run at all?**
If yes, Type 1 (hallucinated code) is the likely culprit. Look at the error message. Does it reference a missing module, undefined function, or wrong API?

**Step 2: Does it run but behave unexpectedly?**
If yes, check if the unexpected behavior is in a file you asked to change (probably Type 3 scope creep) or a file that wasn't supposed to change (probably Type 2 context drift). Run `git diff` to see exactly what changed.

**Step 3: Is the problem in new code or old code?**
New code that AI just wrote: fix forward. Old code that used to work and now doesn't: roll back first, then retry the prompt with tighter constraints.

---

## Recovery Steps

### For Type 1 (Hallucinated Code)

1. Read the error message fully. Don't skim.
2. Find the exact line that's failing.
3. Search for the function or package name that doesn't exist.
4. Go back to AI with the error message and the specific line, not the whole problem: "This line is failing: [paste]. The error is: [paste]. The package version is [X]. What's the correct syntax?"
5. If AI keeps hallucinating the same thing, ask it to check the official docs pattern: "Show me the exact syntax from the [library name] v[version] documentation for doing [X]."

### For Type 2 (Context Drift)

1. Stop the session.
2. Run `git diff` to see everything that changed.
3. Roll back to your last commit: `git checkout -- .` (reverts all unstaged changes) or `git reset --hard HEAD~1` (undoes the last commit entirely).
4. Start a fresh chat or fresh context window.
5. At the top of the new session, paste: your one-sentence goal, the relevant section from CLAUDE.md, and the specific file you want to change. Nothing else.
6. Use the One-File Rule pattern from the prompt patterns guide.

### For Type 3 (Scope Creep)

1. Run `git diff` to see the full scope of what changed.
2. Identify which changes you actually wanted vs what AI added on its own.
3. Use `git checkout -- [filename]` to revert specific files you didn't want changed.
4. For the file you did want changed: either keep the relevant parts manually or ask AI to make only the specific change in isolation: "Remove everything you added except [specific thing]."

---

## Exact Git Commands for Recovery

```bash
# See everything that changed (unstaged)
git diff

# See everything that changed (staged)
git diff --cached

# Revert a single file to its last committed state
git checkout -- src/components/LoginForm.js

# Revert all unstaged changes
git checkout -- .

# Undo the last commit, keep changes staged
git reset --soft HEAD~1

# Undo the last commit, discard changes completely
git reset --hard HEAD~1

# Go back 3 commits, discard everything after
git reset --hard HEAD~3

# Create a recovery branch before a risky fix
git checkout -b recovery-attempt
# (if it fails, go back to main: git checkout main)

# Stash your current mess to come back to it
git stash
# (get it back: git stash pop)
```

---

## Giving AI the Right Context to Fix Its Own Mistakes

The most common debugging mistake is giving AI too much information. You paste the whole file, the whole error log, and a paragraph of explanation. AI picks one thing and runs with it. Half the time, the wrong thing.

Give AI exactly what it needs. No more.

**For compile/runtime errors:**
1. The exact error message (just the error, not the whole log)
2. The exact line that's failing
3. What you expected to happen

**For behavioral bugs:**
1. One sentence: "X should happen when Y. Instead, Z happens."
2. The function or component involved (not the whole file)
3. The relevant inputs and outputs

**The trick that works:** Ask AI to diagnose before it fixes. "Tell me what you think is wrong before you write any code." This forces it to reason about the problem instead of jumping to a solution. Most of the time, the diagnosis is good and the fix becomes obvious.

---

## When to Stop Debugging With AI

If you've tried three different fixes for the same bug and nothing is working, stop using AI for that bug. Switch to manual debugging: console.log checkpoints, isolating the problem to the smallest possible reproduction, reading the actual error documentation.

AI is good at applying known solutions to known patterns. Novel bugs in your specific combination of tools and logic are often not in its training data. At that point, you need to reason it out yourself — or find someone who has seen this exact problem.

AI debugging works best when you're the detective and AI is your research assistant. When you flip those roles and let AI lead the investigation, you often end up chasing the wrong lead.

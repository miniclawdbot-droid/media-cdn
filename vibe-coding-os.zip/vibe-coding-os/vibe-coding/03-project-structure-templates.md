# Project Structure Templates

*Folder templates for 4 common builds. What goes where, what to create first, what to let AI generate.*

---

## Why Structure Matters for AI

AI builds in the shape of the context it has. If you haven't defined a folder structure, AI will invent one — and it won't be consistent. By message 10 it will have created `utils/`, `helpers/`, `lib/`, and `shared/` for the same category of code.

Define the structure before you start. Put it in your CLAUDE.md. AI will follow it if you tell it to.

The templates below are starting points. Adapt them to your project. The specific folders matter less than having defined them clearly.

---

## Template 1: SaaS Web App

**Best for:** Multi-page apps with user accounts, subscriptions, dashboards, and backend logic.

```
/
├── src/
│   ├── app/                    # Next.js app router pages, or React routes
│   │   ├── (auth)/             # Login, signup, reset password
│   │   ├── dashboard/          # Main logged-in experience
│   │   └── api/                # API route handlers
│   ├── components/
│   │   ├── ui/                 # Generic UI: buttons, inputs, modals
│   │   └── features/           # Feature-specific components (UserCard, PlanBadge)
│   ├── lib/
│   │   ├── db.ts               # Database client and connection
│   │   ├── auth.ts             # Authentication helpers
│   │   └── stripe.ts           # Payment integration
│   ├── hooks/                  # Custom React hooks
│   ├── types/                  # TypeScript types and interfaces
│   └── utils/                  # Pure utility functions (no side effects)
├── prisma/                     # Database schema and migrations
│   └── schema.prisma
├── public/                     # Static assets (images, fonts, favicon)
├── tests/                      # Tests (mirror the src/ structure)
├── .env.example                # Env var template (never commit .env)
├── CLAUDE.md                   # AI rules for this project
└── PRD.md                      # Your filled-out PRD template
```

**Create first:** `CLAUDE.md`, `PRD.md`, `.env.example`, `prisma/schema.prisma`, `src/lib/db.ts`, `src/lib/auth.ts`

**Let AI generate:** Individual page components, UI components, API route handlers, hooks for specific features.

**Notes:**
- Keep `lib/` for singleton instances and integrations (one database client, one auth config). If there's more than one file doing the same job, you have a structure problem.
- `components/ui/` should be stateless and reusable. `components/features/` is where business logic lives in UI.
- Every new feature gets its own folder inside `features/`. Don't dump everything flat.

---

## Template 2: Landing Page + Waitlist

**Best for:** Pre-launch pages, product announcements, email capture, invite flows.

```
/
├── src/
│   ├── app/
│   │   ├── page.tsx            # The landing page
│   │   ├── layout.tsx          # Root layout
│   │   └── api/
│   │       └── waitlist/       # Waitlist signup endpoint
│   │           └── route.ts
│   ├── components/
│   │   ├── Hero.tsx            # Above-the-fold section
│   │   ├── Features.tsx        # Feature highlights
│   │   ├── Testimonials.tsx    # Social proof (or placeholder)
│   │   ├── Pricing.tsx         # Pricing section (even if TBD)
│   │   ├── FAQ.tsx             # Common objections
│   │   └── WaitlistForm.tsx    # Email capture + submit
│   ├── lib/
│   │   └── email.ts            # Email service integration (Resend, Mailchimp, etc.)
│   └── utils/
│       └── analytics.ts        # Event tracking helpers
├── public/
│   ├── og-image.png            # Open Graph image for social sharing
│   └── logo.svg
├── content/
│   └── copy.ts                 # All headline and body copy in one file
├── .env.example
└── CLAUDE.md
```

**Create first:** `CLAUDE.md`, `src/app/page.tsx` (stub), `content/copy.ts`, `.env.example`

**Let AI generate:** Component files, the API route handler, analytics helpers, email integration.

**Notes:**
- The `content/copy.ts` trick is underrated. Put every headline, subheadline, and CTA string in one file. When the copy changes (and it will), you change one file, not 12 components.
- Build the page as a sequence of components, not a single long file. You'll swap sections in and out as you test different messaging.
- Don't skip the OG image. It affects every link share.

---

## Template 3: REST API

**Best for:** Backend services, mobile app backends, internal APIs, webhook handlers.

```
/
├── src/
│   ├── routes/                 # Route definitions (one file per resource)
│   │   ├── users.ts
│   │   ├── products.ts
│   │   └── webhooks.ts
│   ├── controllers/            # Request handling logic (thin layer)
│   │   ├── users.controller.ts
│   │   └── products.controller.ts
│   ├── services/               # Business logic (the meat of the app)
│   │   ├── users.service.ts
│   │   └── products.service.ts
│   ├── middleware/             # Auth, validation, rate limiting, logging
│   │   ├── auth.ts
│   │   ├── validate.ts
│   │   └── rateLimit.ts
│   ├── models/                 # Database models or Prisma types
│   ├── lib/
│   │   ├── db.ts
│   │   └── logger.ts
│   └── utils/
│       └── errors.ts           # Custom error classes and handlers
├── tests/
│   ├── routes/
│   └── services/
├── prisma/ (or migrations/)
├── .env.example
├── CLAUDE.md
└── PRD.md
```

**Create first:** `CLAUDE.md`, `PRD.md`, `src/lib/db.ts`, `src/middleware/auth.ts`, `src/utils/errors.ts`, `.env.example`

**Let AI generate:** Individual route files, controller stubs, service implementations, test scaffolding.

**Notes:**
- The Controller/Service split exists for a reason. Controllers are thin (parse request, call service, return response). Services have the logic. Never put business logic in routes.
- Start with one resource end-to-end before adding more. Users with CRUD before you add Products. Proves the architecture, catches integration issues early.
- Put every error response format in `utils/errors.ts` from the start. Consistent error shapes are a gift to whoever calls your API.

---

## Template 4: CLI Tool

**Best for:** Command-line utilities, automation scripts, developer tools.

```
/
├── src/
│   ├── commands/               # One file per command
│   │   ├── init.ts
│   │   ├── run.ts
│   │   └── config.ts
│   ├── lib/
│   │   ├── config.ts           # Config loading and validation
│   │   ├── logger.ts           # Console output formatting
│   │   └── api.ts              # Any external API calls
│   └── utils/
│       ├── files.ts            # File system helpers
│       └── prompts.ts          # Interactive prompts (Inquirer, Clack, etc.)
├── bin/
│   └── cli.ts                  # Entry point — sets up the CLI framework
├── tests/
│   └── commands/
├── .env.example
├── package.json
├── tsconfig.json
├── CLAUDE.md
└── README.md                   # User-facing docs (not your internal README)
```

**Create first:** `CLAUDE.md`, `bin/cli.ts` (entry point), `src/lib/config.ts`, `src/lib/logger.ts`

**Let AI generate:** Individual command files, utility helpers, interactive prompts, test files.

**Notes:**
- `bin/cli.ts` is the entry point. This is where you define the CLI structure and wire up commands. Keep it short — wiring only, no logic.
- Good CLI output is a feature. Invest in your logger early. Color, spacing, and clear error messages make your tool feel professional.
- Ship `--help` text from day one. AI is good at generating help descriptions if you tell it to.

---

## Telling AI About Your Structure

Once you've chosen a template and adapted it, put the structure in CLAUDE.md like this:

```markdown
## Folder Structure

Follow this structure. Do not create new top-level folders without asking.

[paste your directory tree here]

Rules:
- Business logic goes in /services/, not in /routes/ or components
- No new util files unless you've checked /utils/ doesn't already have what you need
- All env vars must be in .env.example (never hardcoded)
```

Then paste this into every new chat at the start of the session. AI will follow it.

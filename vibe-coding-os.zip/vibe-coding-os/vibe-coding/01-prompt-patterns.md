# Prompt Patterns That Actually Work

*15 patterns for building with AI. Each includes the template, a real example, and why it works.*

---

## How to Use This

These aren't magic incantations. They're structures that get AI to behave in specific, useful ways. The templates use `[brackets]` for the parts you fill in. The rest is the pattern.

Read through all of them once to know what exists. Then come back when you need a specific one.

---

## Scoping Patterns

### 1. The One-File Rule

**When to use:** Before any task that might sprawl across multiple files.

**Template:**
```
Only touch [filename]. Do not modify any other file, even if you think it would help. If you need to make changes elsewhere to make this work, list them and stop. I'll tell you which to do next.
```

**Example:**
Input: "Only touch `auth.js`. Do not modify any other file. I want to add a logout function."
Output: AI adds the logout function to `auth.js` only, lists that `routes.js` also needs a new route, and waits.

**Why it works:** Without this constraint, AI will "helpfully" update every file it thinks is related. That's how a 5-minute task turns into a 30-minute audit. One file, one focus.

---

### 2. The Scope Declaration

**When to use:** At the start of any session where you know exactly what you want.

**Template:**
```
This session: [specific goal]. That's it. If I ask about anything outside this, remind me to save it for later.
```

**Example:**
Input: "This session: build the user settings page. That's it."
Output: AI focuses on settings only. When you say "oh, and we should probably fix the nav too," it reminds you that's out of scope.

**Why it works:** Giving AI permission to hold you accountable is one of the most underused patterns. It becomes a second set of eyes on scope creep.

---

### 3. Plan Before You Build

**When to use:** Any change touching more than two files, or anything architectural.

**Template:**
```
Before writing any code, describe your plan: what you'll do, every file you'll touch, and what each change accomplishes. Wait for my approval.
```

**Example:**
Input: "Before writing any code, describe your plan for adding user authentication."
Output: AI explains the approach (JWT, middleware, routes, schema changes), lists 5 files it will touch, waits for you to say go.

**Why it works:** AI plans differently when it knows you're going to read the plan. It slows down and thinks in steps instead of jumping to implementation.

---

### 4. Feature Flag It

**When to use:** Adding a new feature you're not ready to ship yet.

**Template:**
```
Add [feature] behind a feature flag. The flag should be a constant at the top of [filename]. Set it to false. The feature should do nothing when the flag is off.
```

**Example:**
Input: "Add the premium content section behind a feature flag. Flag at the top of `config.js`, set to false."
Output: Adds `PREMIUM_ENABLED = false` to config, wraps the premium section in a check. You flip it to true when ready.

**Why it works:** Lets you build incrementally without breaking what's live. Also gives AI a clean on/off structure to work with.

---

## Debugging Patterns

### 5. The Rubber Duck Dump

**When to use:** Something is broken and you don't know why.

**Template:**
```
I have a bug. Here's what I expected: [expected]. Here's what's happening: [actual]. Here's the relevant code: [paste code]. Don't fix it yet. Tell me what you think is wrong and why.
```

**Example:**
Input: "I have a bug. Expected: login redirects to dashboard. Actual: redirects to login again. Here's my auth middleware: [paste]. Don't fix it yet. Tell me what you think is wrong."
Output: AI diagnoses the issue (probably a missing `return` or middleware order problem), explains why. You confirm the diagnosis before any code changes.

**Why it works:** Separating diagnosis from fix prevents AI from "solving" the wrong problem. Half of debugging is naming the problem correctly.

---

### 6. Binary Search Debug

**When to use:** You have a big block of code and no idea where the bug is.

**Template:**
```
I need to find a bug. Add a `console.log("[checkpoint X]")` at [location] and tell me what value I should see there if everything is working correctly. We'll narrow it down step by step.
```

**Example:**
Input: "Add `console.log('[checkpoint 1]', userId)` right after the database query. What should `userId` be if the query works?"
Output: AI adds the log, tells you it should be a non-null string. You run it, check the value, and report back.

**Why it works:** Systematic isolation beats random changes. AI is better at generating checkpoints than at guessing which of 50 lines is wrong.

---

### 7. The Minimal Repro

**When to use:** A bug is intermittent or hard to explain.

**Template:**
```
Help me write the smallest possible code that reproduces this bug. No imports, no dependencies beyond [minimal deps]. Just the logic that's breaking.
```

**Example:**
Input: "Help me write the smallest code that shows this sorting bug. No database, no API calls. Just an array and the sort function."
Output: AI strips everything down to a 10-line example. You can now debug in isolation.

**Why it works:** Most bugs are simpler than the code around them. Stripping away everything else forces the issue to the surface.

---

## Refactoring Patterns

### 8. The Surgical Refactor

**When to use:** You want to clean up code without changing behavior.

**Template:**
```
Refactor [function/file] for readability. Rules: same inputs, same outputs, same behavior. No new logic. No new dependencies. Show me the diff before applying.
```

**Example:**
Input: "Refactor the `validateUser` function for readability. Same inputs, same outputs, same behavior. Show diff first."
Output: AI cleans up variable names, extracts a helper, removes nesting. Shows before/after. You approve.

**Why it works:** "Refactor" without constraints is an invitation to rewrite everything. Adding "same inputs, same outputs, same behavior" keeps AI from inventing new behavior while cleaning up old code.

---

### 9. Extract the Function

**When to use:** You have a long function you want to break apart.

**Template:**
```
This function is too long. Identify the 2-3 logical chunks inside it. Extract each into its own named function. The original function should call them in sequence. Show me the names you'd give each extracted function before writing any code.
```

**Example:**
Input: "This `processOrder` function is too long. Identify the chunks, propose function names."
Output: AI identifies validation, inventory check, and payment processing as natural chunks. Proposes `validateOrder`, `checkInventory`, `chargePayment`. You rename as needed, then approve.

**Why it works:** Naming is the hardest part of refactoring. Getting AI to propose names before writing code lets you course-correct before it's built.

---

### 10. Dead Code Hunter

**When to use:** You want to clean up a file without breaking anything.

**Template:**
```
Review [filename]. List every function, variable, or import that appears to be unused. Do not delete anything. Just list them with your confidence level (certain / likely / unsure) for each.
```

**Example:**
Input: "Review `utils.js`. List everything that appears unused, with confidence level."
Output: AI lists `formatDate` (certain — never called), `API_TIMEOUT` (likely — only in a commented block), `parseCSV` (unsure — might be called dynamically). You decide what to delete.

**Why it works:** AI is good at static analysis. Making it report rather than act prevents the "oops, that was load-bearing" mistake.

---

## Feature Addition Patterns

### 11. The API-First Add

**When to use:** Adding a backend feature or integration.

**Template:**
```
Before writing any implementation, define the API surface: function name, input parameters (with types), return value (with type), and any error cases. I'll approve the API, then you implement it.
```

**Example:**
Input: "We need to add Stripe payment processing. Before any implementation, define the API surface."
Output: AI proposes `chargeCard(amount: number, token: string, currency: string): Promise<{success: boolean, chargeId: string}>`. You adjust the signature, then say build it.

**Why it works:** Locking down the interface before the implementation means you won't have to refactor callers when the implementation is done. Design before code.

---

### 12. The Incremental Add

**When to use:** Adding a feature that could be built in stages.

**Template:**
```
Build [feature] in the smallest possible first step that still works end-to-end. No edge cases, no error handling, no UI polish. Just working core logic. We'll add the rest after I confirm this works.
```

**Example:**
Input: "Build user avatar upload in the smallest working first step. No size validation, no format checks, no cropping. Just upload and display."
Output: AI builds a basic file input, uploads to storage, stores the URL, displays it. Core loop works. You confirm, then add validation and polish in the next step.

**Why it works:** Getting to a working state fast reveals assumptions that diagrams and discussions miss. Always better to discover edge cases on working code than broken scaffolding.

---

### 13. The "Add Without Breaking" Pattern

**When to use:** Adding to a feature area that already works.

**Template:**
```
Add [new thing] to [existing feature]. The existing behavior must not change. List what you're adding vs what you're leaving alone before you start.
```

**Example:**
Input: "Add 'remember me' checkbox to the login form. Existing login behavior must not change. List what you're adding vs leaving alone."
Output: AI lists it will add the checkbox UI, add a flag to the auth call, extend the session duration when flagged. Will not touch the login validation or redirect logic.

**Why it works:** Making AI state explicitly what it won't touch creates accountability. If it modifies something it said it wouldn't, you'll catch it in review.

---

## Code Review Patterns

### 14. The Security Audit

**When to use:** Before you ship anything that handles user input or sensitive data.

**Template:**
```
Review [filename or code block] for security issues only. Look for: SQL injection, XSS, exposed secrets, unvalidated inputs, broken auth, sensitive data in logs. List issues by severity (critical / high / medium). Don't fix anything.
```

**Example:**
Input: "Review my API routes for security issues. SQL injection, unvalidated inputs, exposed errors. List by severity."
Output: AI finds a critical issue (raw SQL query), two high issues (error messages exposing stack traces), one medium (no rate limiting on login). You prioritize and fix.

**Why it works:** Mixing security review with feature review gets you neither. A focused security pass with a severity rating is immediately actionable.

---

### 15. The Explain Pass

**When to use:** You don't fully understand code AI wrote (or code you inherited).

**Template:**
```
Explain [code block] line by line. For each significant line, tell me: what it does, why it might be written this way, and any alternatives that exist.
```

**Example:**
Input: "Explain this middleware function line by line. What it does, why written this way, alternatives."
Output: AI walks through each line, explains that `next()` is called to pass control, explains the async pattern used, mentions that some devs prefer a wrapper pattern instead.

**Why it works:** You should understand everything in your codebase. When you don't, this pattern catches you up fast. Understanding the code is the first step to maintaining it.

---

### 16. The Performance Pass

**When to use:** Before launch, or when something feels slow.

**Template:**
```
Review [filename or function] for performance issues. Look for: N+1 queries, missing indexes, redundant computation, memory leaks, unnecessary re-renders. Don't fix — list with explanation.
```

**Example:**
Input: "Review my dashboard data loading code for performance. N+1 queries, missing indexes, anything obviously slow."
Output: AI spots that the dashboard makes a separate DB query for each user's stats (classic N+1), suggests batching. Also flags an array being rebuilt on every render.

**Why it works:** Performance problems are often invisible until you know to look for them. A named checklist gives AI a search pattern instead of a vague "make it faster" mandate.

---

## A Note on Combining Patterns

Most real sessions use two or three patterns together. Start with Plan Before You Build (#3). During the build, use the One-File Rule (#1). Before shipping, run The Security Audit (#14).

The patterns compound. The more consistently you use them, the less cleanup you do between sessions.

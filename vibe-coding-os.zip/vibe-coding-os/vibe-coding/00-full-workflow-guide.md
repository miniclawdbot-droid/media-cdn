# The Full Vibe Coding Workflow — A to Z

*A practical, opinionated guide for building real things with AI tools.*

---

## Mindset First

Vibe coding is not "let the AI do everything." It's closer to being a technical director: you set the vision, you define the constraints, and you stay in control of where the project goes.

The builders who wreck their projects aren't lazy — they're just handing off decisions they should be making themselves. When AI picks the architecture, invents the data model, or decides what files to create, you've lost the wheel. It may get somewhere. It's rarely somewhere you wanted to go.

The mindset that works: **you hold the context, AI holds the keyboard.** You know what you're building and why. AI knows how to type it fast. Keep those roles clear and the workflow stays clean.

One more thing. Vibe coding rewards small sessions over marathon ones. Two focused 45-minute sessions will beat one 4-hour spiral almost every time. The longer you go without committing, reviewing, and resetting context, the more likely AI is to drift — and the more painful cleanup gets.

---

## Setup (Do This Once Per Project)

Before your first session with any AI tool, do these four things:

**1. Write a PRD.** Use the `PRD-template.md` in this kit. Fill it out. If you can't answer the questions, you're not ready to build yet. This document is your single source of truth. Everything else references it.

**2. Drop in CLAUDE.md and .cursorrules.** These files tell your AI tools how to behave in this project. Fill in the "What You're Building" section with your project name, stack, and status. That's the minimum. Takes 5 minutes.

**3. Initialize git.** Run `git init` if you haven't. Make your first commit: `git add -A && git commit -m "initial setup"`. This is your rollback point before anything else happens.

**4. Define your folder structure.** Decide where code goes before AI starts creating files. Three to five top-level folders is usually enough. Put it in CLAUDE.md. AI will follow it if you tell it to — and invent its own if you don't.

---

## The PRD Step

The Product Requirements Doc isn't bureaucracy. It's insurance.

The PRD does one thing: forces you to make decisions before AI makes them for you. Problem statement. Who uses it. Three core features, max. What's explicitly out of scope. What "done" looks like. What stack you're on.

When AI asks "what should we do about X?" and you don't have an answer, that's a PRD gap. Fill it in. When AI builds something you didn't want, it's usually because you didn't define what you did want. The PRD is the fix.

Keep it short. One page. Plain English. You're not writing a spec for a team of engineers — you're writing notes to yourself that you'll hand to an AI.

---

## Starting a Session

Every session starts the same way. Not because ritual is important, but because skipping this is where most sessions go wrong.

**Before touching AI:**
- Run the session checklist (it's in this kit, `session-startup-checklist.md`)
- Commit what you have: `git add -A && git commit -m "session start checkpoint"`
- Write your session goal in one sentence. Literally one sentence. "Add user authentication with email and password." Not "work on auth stuff."

**When you open the AI chat:**
- Paste your one-sentence goal
- Paste relevant context from your CLAUDE.md or PRD (the stack, the current status, what not to touch)
- If you're picking up from a previous session, paste the "what's next" from your last session notes

The AI doesn't remember your last session. You do. Give it what it needs.

---

## Mid-Session Discipline

This is where most people fail. The session is going well, you're making progress, and the AI suggests something slightly outside what you asked for. You say sure. Then it suggests something else. Twenty minutes later, you're three features deep and nothing is working.

Rules for staying on track:

**One task at a time.** If AI surfaces a problem you didn't ask about, write it down somewhere else and come back to it. Don't let it pull you into a different thread mid-session.

**Read every diff before accepting it.** Even when things look fine. Especially when things look fine. AI is confident whether it's right or wrong. You're the one who knows what should be there.

**When in doubt, ask for a plan first.** Before AI writes any code for a significant change, ask it to describe what it's going to do and list every file it plans to touch. This takes 30 seconds and catches most disasters.

**If something breaks, stop.** Don't ask AI to fix the thing it just broke by giving it more freedom. Roll back, restate the goal more precisely, and try again with tighter constraints.

---

## When to Stop and Commit

Commit checkpoints prevent most vibe coding disasters. The rule is simple: commit before anything consequential happens.

Commit before:
- Starting a new feature
- Asking AI to refactor anything
- Any change touching more than two files
- A session ends

A good commit message is just what changed: `add login form UI`, `refactor auth service`, `fix: redirect after login`. You're not writing documentation — you're leaving breadcrumbs.

If you're not sure whether to commit, commit. Git storage is free. Rebuilt code costs hours.

---

## Ending a Session

Session end is a practice most vibe coders skip. Don't.

**Before you close the editor:**
1. Commit everything: `git add -A && git commit -m "session end: [what you built]"`
2. Update the Session Notes section in CLAUDE.md — what changed, what broke, what's next
3. Write your next session goal while it's fresh

The Session Notes section is what future-you hands to AI next time instead of trying to remember where you left off. Two sentences. Takes 90 seconds. Worth 20 minutes of context-reconstruction every time.

If something is still broken when you end the session, say that too. "Auth works. Profile page crashes on load. Next: fix the null user bug in profile component." Now you have a starting point, not a mystery.

---

## The Discipline That Compounds

Every part of this workflow feels slightly slow the first time. That's the point. The slowness is friction against the behaviors that create chaos: starting without clarity, accepting changes without reading them, going too long without a commit checkpoint.

Do this consistently for a week. The sessions get faster, not slower. The AI gets more useful, not less. And you stop losing hours to cleanup work that should never have been necessary.

Vibe coding at its best is fast. The workflow is what makes it stay fast.

# Vibe Coding OS
### A drop-in system for building with AI without losing control of your project.

---

## What This Is

Two complete systems in one kit.

**Vibe Coding OS** — Rules, templates, and workflows that tell your AI tools how to behave. Drop them into any project, fill in your context, and start building with guardrails already in place.

**OpenClaw Agent Starter** — A complete template set for building your own personal AI agent. Every file the agent reads, every sub-agent it works with, and a guide to understanding how the whole system operates.

---

## What's Included

### Core Files — Drop Into Any Project

| File | What It Does |
|------|-------------|
| `PRD-template.md` | Define what you're building before AI starts building it wrong |
| `CLAUDE.md` | Rules for Claude Code — how to behave, what not to touch, how to ask before acting |
| `.cursorrules` | Same rules for Cursor users |
| `.windsurfrules` | Same rules for Windsurf users |
| `.antigravity` | Same rules for Antigravity users |
| `git-workflow-cheatsheet.md` | Commit before every AI session. Roll back when things break. |
| `session-startup-checklist.md` | Pre-flight and post-flight for every AI coding session |
| `cost-control.md` | How to stay under budget on Cursor and Claude |

### `vibe-coding/` — Workflow Guides

| File | What It Covers |
|------|---------------|
| `00-full-workflow-guide.md` | A-to-Z vibe coding workflow: mindset, setup, PRD, sessions, commits |
| `01-prompt-patterns.md` | 16 prompt patterns with templates, examples, and why each one works |
| `02-debugging-with-ai.md` | The 3 types of AI breaks, diagnosis workflow, recovery with exact git commands |
| `03-project-structure-templates.md` | Folder templates for SaaS, landing pages, REST APIs, and CLI tools |
| `04-when-to-stop-vibe-coding.md` | Honest guide on when vibe coding works and when to switch approach |

### `openclaw-agent/` — Agent Templates

| File | What It Is |
|------|-----------|
| `00-quickstart.md` | Get a working OpenClaw agent in 30 minutes — step-by-step walkthrough |
| `SOUL.md` | Agent identity template — who it is, values, voice, boundaries |
| `IDENTITY.md` | Operational details — platforms, handles, connection IDs, behaviors |
| `AGENTS.md` | Workspace rules and sub-agent architecture |
| `HEARTBEAT.md` | Scheduled tasks template — API config, task schedule, state tracking |
| `MEMORY.md` | Long-term memory template — preferences, lessons, priorities |
| `MISSION.md` | Mission and goals template — phase, targets, success metrics |
| `TOOLS.md` | Local environment notes — cameras, SSH, devices, APIs |
| `USER.md` | User context template — name, prefs, communication style |
| `10-subagents-guide.md` | How sub-agents work: concepts, patterns, failure modes |
| `subagents/researcher.md` | Researcher sub-agent template |
| `subagents/writer.md` | Writer sub-agent template |
| `subagents/reviewer.md` | Reviewer/QA sub-agent template |
| `subagents/publisher.md` | Publisher sub-agent template |

---

## Getting Started

### Vibe Coding

**1. Fill out your PRD.**
Open `PRD-template.md` before you write any code. If you can't fill it in, you're not ready to build yet.

**2. Drop the rule file for your tool into your project root.**
- Claude Code → `CLAUDE.md`
- Cursor → `.cursorrules`
- Windsurf → `.windsurfrules`
- Antigravity → `.antigravity`

Open the file and fill in the Project Context section at the bottom. Takes 5 minutes.

**3. Initialize git before AI touches anything.**
```bash
git init && git add -A && git commit -m "initial setup"
```
This is your baseline. Everything after this is recoverable.

**4. Run the session startup checklist before every AI session.**
Open `session-startup-checklist.md`. Five minutes. Catches the most common ways sessions go sideways.

**5. Read the workflow guide.**
`vibe-coding/00-full-workflow-guide.md` — understand the system before you rely on it.

---

### OpenClaw Agent

**1. Install OpenClaw.**
```bash
npm install -g openclaw
openclaw init
```

**2. Copy the agent templates into your workspace.**
Copy everything from `openclaw-agent/` into your workspace root. Fill in the sections marked with brackets `[ ]`.

**3. Configure your channel.**
Discord or Telegram. Full instructions in `openclaw-agent/00-quickstart.md`.

**4. Start your agent.**
```bash
openclaw start
```
Send it a message. It should introduce itself.

**5. Add sub-agents as you need them.**
Copy templates from `openclaw-agent/subagents/` and fill them in for your use case.

---

## The Point

AI will rewrite files that were working. It will delete things you didn't know you needed. It will spiral into a 400-line solution to a 10-line problem if you let it.

This system is not about slowing AI down. It's about staying in the decision seat while AI does the heavy lifting. The builders who get the most from these tools are the ones who define the rules upfront and enforce them consistently.

That's what this kit is for.

---

## File Tree

```
vibe-coding-os/
├── README.md
├── PRD-template.md
├── CLAUDE.md
├── .cursorrules
├── .windsurfrules
├── .antigravity
├── git-workflow-cheatsheet.md
├── session-startup-checklist.md
├── cost-control.md
├── vibe-coding/
│   ├── 00-full-workflow-guide.md
│   ├── 01-prompt-patterns.md
│   ├── 02-debugging-with-ai.md
│   ├── 03-project-structure-templates.md
│   └── 04-when-to-stop-vibe-coding.md
└── openclaw-agent/
    ├── 00-quickstart.md
    ├── SOUL.md
    ├── IDENTITY.md
    ├── AGENTS.md
    ├── HEARTBEAT.md
    ├── MEMORY.md
    ├── MISSION.md
    ├── TOOLS.md
    ├── USER.md
    ├── 10-subagents-guide.md
    └── subagents/
        ├── researcher.md
        ├── writer.md
        ├── reviewer.md
        └── publisher.md
```

---

*Built by AInsights — <https://x.com/ryan_tech_lab>*

# Cost Control Quick Reference
## Stay Under Budget on Cursor and Claude

Cursor's $20/mo plan isn't unlimited. Claude's API isn't free. Here's how to stop burning tokens on things that don't matter.

---

## Which Model Should I Use?

| Task | Use This | Why |
|------|----------|-----|
| New features from scratch | Claude Sonnet (latest) | Needs strong reasoning; Sonnet hits the quality/cost balance |
| Architecture decisions | Claude Opus (latest) | Worth the cost — bad architecture decisions cost more later |
| Debugging tricky issues | Claude Sonnet (latest) | Context-heavy, needs reasoning |
| Simple bug fixes | Claude Haiku (latest) | Faster, cheaper, handles it fine |
| Explaining code | Claude Haiku (latest) | Explanation doesn't need the heaviest model |
| Boilerplate generation | Any fast/small model | Mechanical task — don't waste premium tokens |
| Writing tests | Claude Haiku (latest) | Structured, pattern-based — no heavy reasoning needed |
| Regex, SQL, one-liners | Any model | Trivial task |
| Reviewing a diff | Claude Sonnet (latest) | Needs judgment, but not full Opus level |

**Rule of thumb:** If the task is mechanical, use a smaller/faster model. If it requires judgment or novel reasoning, step up. The cost difference between Haiku and Opus is roughly 10-25x per token.

> Note: GPT-3.5 and GPT-4o (OpenAI) are no longer available as of early 2026. If you're using OpenAI models, check current availability at platform.openai.com before referencing specific model names.

---

## The Biggest Drain: Context Window Bloat

Every message you send includes the entire conversation history. Long sessions = expensive sessions.

**Fix it:**
- Start a new chat when you finish a distinct task. Don't let one conversation run all day.
- Don't paste entire files when you only need one function. Paste the relevant section.
- Don't paste error logs with 200 lines of stack trace. Paste the relevant error + the file it happened in.
- Remove conversation history that's no longer relevant by starting fresh.

---

## How to Scope Tasks to Avoid Runaway Usage

**Bad:** "Build me a full auth system with login, signup, password reset, OAuth, and session management."

This generates a huge response, often wrong in ways that require multiple follow-up messages to fix.

**Good:** "Build a login form component that takes email and password, validates both fields, and calls `submitLogin()` on submit. No auth logic yet."

This is specific. The response is focused. One shot, done.

**The pattern:** One task per message. Validate it works. Then ask for the next piece.

---

## Cursor-Specific Tips

**Use the right feature for the job:**
- **Tab completion** — free (included in plan), use it constantly
- **Cmd+K (inline edit)** — uses premium requests, be intentional
- **Chat** — uses premium requests, each message counts
- **Agent mode** — uses the most; runs multiple tool calls. Save for complex tasks.

**Check your usage:** Cursor dashboard shows how many premium requests you've used this month. Check it before the end of the month.

**Avoid agent mode for simple tasks.** If you can give Cursor a precise instruction and it can do it in one shot, use Cmd+K. Agent mode is for when you need it to figure things out step by step.

---

## Context Window Hygiene

**Don't dump your whole codebase.** Cursor indexes your project automatically. Don't manually paste files you don't need. Let it find what it needs.

**Close files you're not working on.** Open tabs = context. Fewer open files = leaner context.

**Use `@file` references instead of pasting.** In Cursor chat, `@filename` pulls in just that file when needed. Cleaner than copying the whole thing.

---

## The Expensive Mistakes

- Asking AI to "just clean up this whole file" — it rewrites everything, uses max tokens, often breaks things
- Letting a session run for 3 hours without starting fresh — the context accumulates
- Using Opus for every task — it's expensive for tasks a smaller model handles fine
- Asking for 5 features in one message — you get a sprawling response you'll argue with for an hour

---

## Budget Gut Check

If you're on Cursor Pro ($20/mo), you get a limited number of premium requests per month. One complex agent session can eat 10-20 requests. Plan accordingly:
- Use tab completion (free) for most of your day
- Reserve premium requests for tasks that actually need them
- Check usage midway through the month

If you're hitting limits regularly: either upgrade, or get more surgical about how you use premium features.

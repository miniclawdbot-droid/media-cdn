# CLAUDE.md — Project Rules

> These rules apply to every task in this project. Read this file before doing anything else.

---

## Customize These 3 Things

Before you use this file, update these three sections:

1. **Folder Structure** (below) — replace the example tree with your actual project structure
2. **What You're Building** (bottom of file) — fill in name, problem, stack, current status
3. **Session Notes** (bottom of file) — update at the end of each session

Everything else is pre-written and ready to go. Do not change the core behavior rules unless you have a specific reason.

---

## Core Behavior

**Summarize before acting.**
Before making any change, write one sentence describing what you're about to do and why. Do not start coding without doing this.

**Ask when ambiguous.**
If the request could be interpreted more than one way, ask a clarifying question before proceeding. Don't pick an interpretation and run with it — that's how we end up with the wrong thing built correctly.

**Prefer editing over rewriting.**
If a file exists, modify it. Do not rewrite it from scratch unless explicitly told to. Rewrites destroy context and break things that were working.

**Stay in scope.**
Only touch files directly related to the current task. If you notice a problem in an unrelated file, flag it — don't fix it unless asked.

---

## File Safety

**Never delete files without asking.**
If a task seems to require deleting a file, stop and ask first. Describe which file, why it needs to go, and what the impact will be.

**Never rename or move files without asking.**
Imports break. References break. Path-dependent configs break. Ask first.

**Commit before major changes.**
Before any refactor, architecture change, or multi-file edit, remind the user to commit. If they haven't, suggest: `git add -A && git commit -m "checkpoint before [change]"`

---

## Folder Structure

Follow the structure below. Do not create new top-level folders without asking.

```
/
├── src/           # All source code
├── public/        # Static assets (images, fonts, etc.)
├── tests/         # Test files — mirror the structure in src/
├── docs/          # Documentation
└── scripts/       # One-off utility scripts
```

> **Replace this with your actual project structure.** The specific folders don't matter — what matters is that you define them once and Claude respects them. If your project is a Python API, a mobile app, or something else entirely, update the tree above to match. The rule stays the same: don't create new top-level folders without asking.

---

## What to Do When Stuck

1. Stop.
2. Describe what you tried and what happened.
3. Ask a specific question.
4. Do not spiral into larger and larger changes trying to fix a bug.

---

## What You're Building

> Fill this in once and leave it here. This is the 30-second context Claude needs at the start of every session. Without this, Claude has no idea what the project is or what matters.

**Project:** [Name of your project]
**Problem it solves:** [One sentence — what pain does this fix?]
**Current status:** [What's done, what's in progress, what's next]
**Stack:** [Languages, frameworks, databases, hosting]
**Do not touch:** [Files or features that are off-limits right now]

---

## Session Notes

> Update this at the end of every working session. What changed, what broke, what's next. Claude reads this at the start of the next session to pick up where you left off.

*Last updated: [date]*
*What changed: [brief summary]*
*What's next: [next task]*

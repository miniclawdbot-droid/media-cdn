# Session Checklist
## Run This at the Start and End of Every AI Coding Session

Copy this. Paste it somewhere accessible. Run it every time. Takes 5 minutes on each end. Saves hours.

---

## Session Start

### Before You Open Cursor or Claude

- [ ] **Check git status.** Run `git status`. If there are uncommitted changes from last time, commit them now before anything else. `git add -A && git commit -m "checkpoint: pre-session"`
- [ ] **Know what you're building today.** Write your goal for this session in one sentence. Not a paragraph. One sentence. If you can't, you're not ready to start.

> **Today's goal:** _______________________________________________

- [ ] **Review your PRD.** Open `PRD-template.md`. Is it still accurate? Has scope changed? Update it before you start. AI works from context — stale context = bad output.
- [ ] **Note what NOT to touch.** What parts of the codebase are off-limits today? Write them down before you open a chat.

> **Do not touch:** _______________________________________________

---

### When You Start the Session

- [ ] **Paste your project context into the chat.** Give the AI your project name, what it does, your stack, and what you're working on today. Don't assume it knows. It doesn't.
- [ ] **Confirm CLAUDE.md or .cursorrules is active.** If you're using Cursor, `.cursorrules` in the project root loads automatically. If you're using Claude Code, CLAUDE.md loads automatically. If you're in a fresh Claude chat, paste the rules at the top.
- [ ] **Start small.** Ask for the smallest useful thing first. Validate it works before going bigger. Don't give AI a 10-step task on the first message.

---

### Midway Check (every 30-60 minutes)

- [ ] **Is it still on track?** Read the last few things AI produced. Is it still solving the right problem?
- [ ] **Commit if anything is working.** Don't wait until the end. `git add -A && git commit -m "wip: [what works so far]"`
- [ ] **Are you in scope?** Check your "do not touch" list. If AI wandered, pull it back now — not after it rewrites three more files.

---

## Session End

### Before You Close Anything

- [ ] **Commit everything.** Do not skip this. `git add -A && git commit -m "feat: [what you built]"`
- [ ] **Push to remote.** `git push` — this is your backup. Local commits only exist on your machine.
- [ ] **Update your PRD** if scope changed during the session. Five minutes now saves confusion next time.
- [ ] **Update CLAUDE.md session notes** with what changed and what's next. One or two sentences is enough.

---

### Handoff to Next Session

- [ ] **Write down where you stopped.** Literally one sentence: "I got X working. Next step is Y. Known issue: Z." This becomes the first thing you paste into the next session.

> **Stopped at:** _______________________________________________
> **Next step:** _______________________________________________
> **Known issue / blocker:** _______________________________________________

- [ ] **Set one goal for next session.** Not a list. One goal. Write it here so you start with direction, not a blank page.

> **Next session goal:** _______________________________________________

---

## The One-Sentence Rule

If you can't write your goal in one sentence, you're about to waste hours building something blurry. AI is a mirror. Vague input, vague output. Sharpen the goal before you start — and record where you ended so the next session starts sharp too.
